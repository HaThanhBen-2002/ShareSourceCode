﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Drawing;

namespace Blumind.Model.MindMaps
{
    partial class MindMap
    {
        /*[DefaultValue(typeof(Color), "White")]
        [LocalDisplayName("Back Color"), LocalCategory("Color")]
        public Color BackColor
        {
            get { return Style.BackColor; }
            set { Style.BackColor = value; }
        }

        [DefaultValue(typeof(Color), "Black")]
        [LocalDisplayName("Fore Color"), LocalCategory("Color")]
        public Color ForeColor
        {
            get { return Style.ForeColor; }
            set { Style.ForeColor = value; }
        }*/

        //[DefaultValue(null), LocalCategory("Color")]
        //public Nullable<System.Drawing.Drawing2D.HatchStyle> BackgroundGrain
        //{
        //    get { return Style.BackgroundGrain; }
        //    set { Style.BackgroundGrain = value; }
        //}

        /*[DefaultValue(typeof(Color), "Black")]
        [LocalDisplayName("Line Color"), LocalCategory("Color")]
        public Color LineColor
        {
            get { return Style.LineColor; }
            set { Style.LineColor = value; }
        }

        [DefaultValue(typeof(Color), "DarkGray")]
        [LocalDisplayName("Border Color"), LocalCategory("Color")]
        public Color BorderColor
        {
            get { return Style.BorderColor; }
            set { Style.BorderColor = value; }
        }

        [DefaultValue(typeof(Color), "White")]
        [LocalDisplayName("Node Back Color"), LocalCategory("Color")]
        public Color NodeBackColor
        {
            get { return Style.NodeBackColor; }
            set { Style.NodeBackColor = value; }
        }

        [DefaultValue(typeof(Color), "Black")]
        [LocalDisplayName("Node Fore Color"), LocalCategory("Color")]
        public Color NodeForeColor
        {
            get { return Style.NodeForeColor; }
            set { Style.NodeForeColor = value; }
        }

        [DefaultValue(typeof(Color), "Highlight")]
        [LocalDisplayName("Selection Color"), LocalCategory("Color")]
        public Color SelectColor
        {
            get { return Style.SelectColor; }
            set { Style.SelectColor = value; }
        }

        [DefaultValue(typeof(Color), "MediumSlateBlue")]
        [LocalDisplayName("Hover Color"), LocalCategory("Color")]
        public Color HoverColor
        {
            get { return Style.HoverColor; }
            set { Style.HoverColor = value; }
        }
        
        [DefaultValue(typeof(Color), "Green")]
        [LocalDisplayName("Link Line Color"), LocalCategory("Color")]
        public Color LinkLineColor
        {
            get { return Style.LinkLineColor; }
            set { Style.LinkLineColor = value; }
        }*/

        /*[DefaultValue(null)]
        [LocalDisplayName("Font"), LocalCategory("Appearance")]
        public virtual Font Font
        {
            get { return Style.Font; }
            set { Style.Font = value; }
        }*/

        /*[DefaultValue(1)]
        [LocalDisplayName("Line Width"), LocalCategory("Appearance")]
        public virtual int LineWidth
        {
            get { return Style.LineWidth; }
            set { Style.LineWidth = value; }
        }

        [DefaultValue(1)]
        [LocalDisplayName("Border Width"), LocalCategory("Appearance")]
        public virtual int BorderWidth
        {
            get { return Style.BorderWidth; }
            set { Style.BorderWidth = value; }
        }

        [DefaultValue(MindMapStyle.DefaultLayerSpace)]
        [DesignOnly(true), LocalDisplayName("Layer Space"), LocalCategory("Layout")]
        public int LayerSpace
        {
            get { return Style.LayerSpace; }
            set { Style.LayerSpace = value; }
        }

        [DefaultValue(MindMapStyle.DefaultItemsSpace)]
        [DesignOnly(true), LocalDisplayName("Items Space"), LocalCategory("Layout")]
        public int ItemsSpace
        {
            get { return Style.ItemsSpace; }
            set { Style.ItemsSpace = value; }
        }*/
    }
}
