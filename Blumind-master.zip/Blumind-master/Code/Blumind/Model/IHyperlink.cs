﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blumind.Model
{
    public interface IHyperlink
    {
        string Hyperlink { get; set; }
    }
}
