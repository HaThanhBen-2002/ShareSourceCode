﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Blumind.Model.Documents
{
    [Serializable]
    enum ChartType
    {
        MindMap,
        FlowDiagram,
    }
}
