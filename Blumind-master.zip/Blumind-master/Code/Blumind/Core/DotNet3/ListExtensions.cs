﻿using System;
using System.Collections.Generic;
using System.Text;

namespace System.Collections.Generic
{
    static class ListExtensions
    {
    }
}
