﻿using System.Windows.Forms;

namespace Blumind.Controls
{
    public static class HotKeys
    {
        public static Keys FullScreen
        {
            get { return Keys.F11; }
        }
    }
}
