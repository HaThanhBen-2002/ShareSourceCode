﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Blumind.Controls
{
    interface IIconProvider
    {
        Image Icon { get; }
    }
}
