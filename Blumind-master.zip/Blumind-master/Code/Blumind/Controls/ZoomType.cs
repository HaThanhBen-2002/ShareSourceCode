﻿
namespace Blumind.Controls
{
    public enum ZoomType
    {
        FitPage,
        FitWidth,
        FitHeight,
        Custom,
    }
}
