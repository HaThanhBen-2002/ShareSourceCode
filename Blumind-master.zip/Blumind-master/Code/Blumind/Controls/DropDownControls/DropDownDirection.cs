﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blumind.Controls
{
    public enum DropDownDirection
    {
        Above,
        AboveLeft,
        AboveRight,
        BelowLeft,
        BelowRight,
        Below,
        Left,
        Right,        
    }
}
