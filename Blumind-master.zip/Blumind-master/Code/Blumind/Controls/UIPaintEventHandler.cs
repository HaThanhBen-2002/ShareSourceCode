﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Blumind.Controls
{
    delegate void UIPaintEventHandler(object sender, PaintEventArgs e, UIControlStatus ucs);
}
