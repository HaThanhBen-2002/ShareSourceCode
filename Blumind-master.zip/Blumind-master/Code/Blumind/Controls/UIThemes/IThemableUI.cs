﻿using System;
using Blumind.Controls;

namespace Blumind.Controls
{
    interface IThemableUI
    {
        void ApplyTheme(UITheme theme);
    }
}
