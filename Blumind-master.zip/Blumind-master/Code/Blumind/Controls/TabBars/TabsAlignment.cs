﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blumind.Controls
{
    enum TabsAlignment
    {
        Near,
        Far,
    }
}
