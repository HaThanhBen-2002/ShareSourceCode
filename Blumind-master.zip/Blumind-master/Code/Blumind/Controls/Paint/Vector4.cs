﻿using System;

namespace Blumind.Controls
{
    [Serializable]
    public enum Vector4
    {
        Left,
        Top,
        Right,
        Bottom,
    }
}
