﻿
namespace Blumind.Controls
{
    public enum HorizontalVector
    {
        Left,
        Right,
    }
}
