﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blumind.Controls.MapViews
{
    public enum MoveVector
    {
        Left,
        Right,
        Up,
        Down,
    }
}
