﻿
namespace Blumind.Controls.MapViews
{
    class MoveCommand
    {
    }
}
