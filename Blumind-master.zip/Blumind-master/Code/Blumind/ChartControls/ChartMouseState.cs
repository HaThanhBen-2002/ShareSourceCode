﻿namespace Blumind.Controls
{
    public enum ChartMouseState
    {
        Normal,
        Drag,
        Select,
        Scroll,
    }

    public enum ChartMouseMethod
    {
        Select,
        Scroll,
    }
}
