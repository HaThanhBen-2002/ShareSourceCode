﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using Blumind.Canvas;
using Blumind.ChartControls.Shapes;

namespace Blumind.ChartControls.Shapes
{
    class Prismatic : Shape
    {
        public override void Fill(IGraphics graphics, IBrush brush, Rectangle rect)
        {
            throw new NotImplementedException();
        }

        public override void DrawBorder(IGraphics graphics, IPen pen, Rectangle rect)
        {
            throw new NotImplementedException();
        }
    }
}
