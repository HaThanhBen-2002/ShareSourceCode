﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Blumind.Configuration
{
    enum ProgramRunMode
    {
        Standard,
        Portable
    }
}
